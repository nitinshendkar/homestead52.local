<?php $__env->startSection('header'); ?>
    <h1>Users</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach($errors->all() as $error): ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <a href="<?php echo e(url('/books/create')); ?>" class="btn btn-success">Create User</a>
    <hr>
    <table class="table table-striped table-bordered table-hover">
        <thead>
        <tr class="bg-info">
            <th>Id</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Home Address</th>
            <th>Office Address</th>
            <th>phone</th>
            <th>employee Id</th>
            <th>Date Of Birth</th>
            <th>Date Of Joining</th>
            <th>Photo</th>
            <th>Signature</th>
            <th>email</th>
            <th>update</th>
            <th>Delete</th>
        </tr>
        </thead>
        <tbody>
         
        <?php foreach($users as $user): ?>
            <tr>
                
                <td><?php echo e($user->id); ?></td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->lastname); ?></td>
                <td><?php echo e($user->home_address); ?></td>
                <td><?php echo e($user->office_address); ?></td>
                <td><?php echo e($user->phone); ?></td>
                <td><?php echo e($user->emp_id); ?></td>
                <td><?php echo e($user->dob); ?></td>
                <td><?php echo e($user->doj); ?></td>
        
                <td><?php echo '<img width=100 height=100 src="data:'.$user->photo_type.';base64,' .$user->photo .'"/>'; ?></td>
                <td><?php echo '<img width=100 height=100 src="data:'.$user->signature_type.';base64,'. $user->signature .'"/>'; ?></td>
                <td><?php echo e($user->email); ?></td>
                
                
                <td><a href="<?php echo e(route('books.edit',$user->id)); ?>" class="btn btn-warning">Update</a></td>
 
                <td>
                    <?php echo Form::open(['method' => 'DELETE', 'route'=>['books.destroy', $user->id]]); ?>

                    <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; ?>

        </tbody>

    </table>

    <?php echo e($users->appends(['sort' => 'updated_at'])->render()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>