<?php $__env->startSection('content'); ?>
    <h1>Finder</h1>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach($errors->all() as $error): ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php echo Form::model('',['method' => 'POST','route'=>['search.find']]); ?>

    <div class="form-group">
        <?php echo Form::label('User Name', 'User First Name/Last Name:'); ?>

        <?php echo Form::text('name',null,['class'=>'form-control']); ?>

    </div>
   <div class="form-group">
        <?php echo Form::submit('Find', ['class' => 'btn btn-primary']); ?>

    </div>
    <?php echo Form::close(); ?>

    <table class="table table-striped table-bordered table-hover">
        <thead>
        <tr class="bg-info">
            <th>Id</th>
            <th>User Name</th>
            <th>Mobile Number</th>
           
        </tr>
        </thead>
        <tbody>
        <?php if(!empty($userlist)): ?>
            <?php foreach($userlist as $user): ?>
            <tr>
                <td><?php echo e($user->id); ?></td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->phone); ?></td>
            </tr>
            <?php endforeach; ?>
        <?php endif; ?>

        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>