<?php $__env->startSection('content'); ?>
<h1>User Address Details</h1>

<?php if(count($errors) > 0): ?>
<div class="alert alert-danger">
    <ul>
        <?php foreach($errors->all() as $error): ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; ?>
    </ul>
</div>
<?php endif; ?>

<a href="<?php echo e(url('/address/create')); ?>" class="btn btn-success">Add User Details</a>
<hr>
<table class="table table-striped table-bordered table-hover">
    <thead>
        <tr class="bg-info">
            <th>Id</th>
            <th>State</th>
            <th>District</th>
            <th>Taluka</th>
            <th>Address Type</th>
            <th>Village</th>
            <th>update</th>
            <th>Delete</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($address as $addressobj): ?>
        <tr>
            <td><?php echo e($addressobj->id); ?></td>
            <td><?php echo e($addressobj->state_name); ?></td>
            <td><?php echo e($addressobj->district_name); ?></td>
            <td><?php echo e($addressobj->taluka_name); ?></td>
            <td>
                <?php if($addressobj->address_type == 'P'): ?>
                Permanant   
                <?php else: ?>
                Temporary
                <?php endif; ?>
            </td>
            <td><?php echo e($addressobj->village); ?></td>
            <?php if( $addressobj->user_id == $loggedInUser ): ?>
            <td><a href="<?php echo e(route('address.edit',$addressobj->id)); ?>" class="btn btn-warning">Update</a></td>

            <td>
                <?php echo Form::open(['method' => 'DELETE', 'route'=>['address.destroy', $addressobj->id]]); ?>

                <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                <?php echo Form::close(); ?>

            </td>
            <?php else: ?>
            <td>&nbsp;</td>

            <td>&nbsp;</td>
            <?php endif; ?>

        </tr>
        <?php endforeach; ?>

    </tbody>
</table>
<?php echo e($address->appends(['sort' => 'updated_at'])->render()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>