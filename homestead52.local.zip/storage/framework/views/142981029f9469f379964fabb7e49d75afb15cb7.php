<?php $__env->startSection('header'); ?>
    Create User
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach($errors->all() as $error): ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    <div class="container">
    <div class="row">
        <div class="centered col-md-4 col-md-offset-4 text-center top_50">
            <div id="logo-container"></div>
            <div class="col-sm-12 col-md-10 ">
                <?php echo Form::open(['route' => 'users.storeapproval']); ?>

                    <?php echo csrf_field(); ?>

                    <div class="form-group input-group">
                        <?php echo Form::label('Users', 'Users:',['class'=>'input-group-addon']); ?>

                        <?php echo Form::select('users', $arraySelectionUserList, NULL,['class'=>'form-control']); ?>


                    </div>
                    <div class="form-group input-group">
                        <?php echo Form::label('Modules', 'Modules:',['class'=>'input-group-addon']); ?>

                        <?php echo Form::select('modules', $modules, NULL,['class'=>'form-control']); ?>

                    </div>
                    
                    <div class="form-group">
                        <button class="btn btn-default "  type="submit">Approve</button>
                    </div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>