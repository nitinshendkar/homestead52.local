<?php $__env->startSection('content'); ?>
    <h1>Personals Details</h1>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach($errors->all() as $error): ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <a href="<?php echo e(url('/personal/create')); ?>" class="btn btn-success">Create Author</a>
    <hr>
    <table class="table table-striped table-bordered table-hover">
        <thead>
        <tr class="bg-info">
            <th>Id</th>
            <th>Date Of Birth</th>
            <th>Date Of Joining</th>
            <th>Signature</th>
            <th>Photo</th>
            <th>update</th>
            <th>Delete</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach($personals as $personal): ?>
            <tr>
                <td><?php echo e($personal->id); ?></td>
                <td><?php echo e($personal->dob); ?></td>
                <td><?php echo e($personal->doj); ?></td>
                <td><?php echo e($personal->photo); ?></td>
                <td><?php echo e($personal->signature); ?></td>
                <td><a href="<?php echo e(route('personal.edit',$personal->id)); ?>" class="btn btn-warning">Update</a></td>

                <td>
                    <?php echo Form::open(['method' => 'DELETE', 'route'=>['personal.destroy', $personal->id]]); ?>

                    <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; ?>

        </tbody>
    </table>
    <?php echo e($personals->appends(['sort' => 'updated_at'])->render()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>