<?php $__env->startSection('content'); ?>
    <h1>Personal Details</h1>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach($errors->all() as $error): ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php echo Form::model($personal,['method' => 'PATCH','route'=>['personal.update',$personal->id]]); ?>

    <div class="form-group">
        <?php echo Form::label('Date Of Birth', 'Date Of Birth:'); ?>

        <?php echo Form::date('dob',null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('Date Of Joining', 'Date Of Joining:'); ?>

        <?php echo Form::date('doj',null ,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('photo', 'photo:'); ?>

        <?php echo Form::file('photo'); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('Signature', 'Signature:'); ?>

        <?php echo Form::file('signature'); ?>

    </div>
   <div class="form-group">
        <?php echo Form::submit('Update', ['class' => 'btn btn-primary']); ?>

    </div>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>