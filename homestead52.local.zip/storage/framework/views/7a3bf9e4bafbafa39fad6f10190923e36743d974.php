<?php $__env->startSection('content'); ?>
    <h1>Update Education Details</h1>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach($errors->all() as $error): ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php echo Form::model($education,['method' => 'PATCH','route'=>['educations.update',$education->id]]); ?>

    <div class="form-group">
        <?php echo Form::label('Degree Name', 'Degree Name:'); ?>

        <?php echo Form::text('degree',null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('Board Name', 'Board Name:'); ?>

        <?php echo Form::text('board',null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('Percentage', 'Percentage:'); ?>

        <?php echo Form::text('percentage',null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('Specialization', 'Specialization:'); ?>

        <?php echo Form::text('specialization',null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('Year Of Passing', 'Year Of Passing:'); ?>

        <?php echo Form::text('year_of_passing',null,['class'=>'form-control']); ?>

    </div>
   <div class="form-group">
        <?php echo Form::submit('Update', ['class' => 'btn btn-primary']); ?>

    </div>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>