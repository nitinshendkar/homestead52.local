<?php $__env->startSection('toolbar'); ?>
    <!-- view/layouts/base.blade.php -->
    <?php if(Auth::guest()): ?>
        <li class="pull-right">
            <a href="<?php echo e(route('login')); ?>">login</a>
             <a href="<?php echo e(route('register')); ?>">register</a>
        </li>
    <?php else: ?>
        <nav class="glyphicon navbar navbar-header navbar-default navbar-fixed-top onTop">
            <div class="container">
                <div class="navbar-header">

                    <div class="navbar-brand glyphicon glyphicon-user pull-left" href="#">
                        <span><?php echo e(Auth::user()->name); ?></span></div>
                </div>
                <div id="navbar" class="collapse navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li class=""><a href="/home">Home</a></li>
                        <li><a href="/users">Users <br>Profile</a></li>
						<li><a href="/educations">&nbsp; <br>Education</a></li>
						<li><a href="/personal">&nbsp; <br>Personal</a></li>
						<li><a href="/banks">&nbsp; <br>Bank</a></li>
						<li><a href="/proffessional">&nbsp; <br>professional</a></li><li><a href="<?php echo e(route('address.index')); ?>">&nbsp;<br>Address</a></li><li><a href="<?php echo e(route('users.createapproval')); ?>">User <br>Approval</a></li>
						<li><a href="<?php echo e(route('search.show')); ?>">Finder</a></li>
                        <li><a href="/paywithpaypal">Make <br>Payment</a></li>
                    </ul>
                    <div class="navbar-brand glyphicon glyphicon-off pull-right" href="#">
                        <span class="caption"><a href="<?php echo e(route('logout')); ?>">Logout</a></span>
                    </div>

                </div><!--/.nav-collapse -->
            </div>
        </nav>

        <?php /*<li><a href="<?php echo e(route('profile', Auth::user()->getKey() )); ?>">Profile</a></li>*/ ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>