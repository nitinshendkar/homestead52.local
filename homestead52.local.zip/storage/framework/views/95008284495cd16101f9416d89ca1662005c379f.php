<?php $__env->startSection('content'); ?>
<h1>Bank Details</h1>

<?php if(count($errors) > 0): ?>
<div class="alert alert-danger">
    <ul>
        <?php foreach($errors->all() as $error): ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; ?>
    </ul>
</div>
<?php endif; ?>

<a href="<?php echo e(url('/banks/create')); ?>" class="btn btn-success">Create Bank Details</a>
<hr>
<table class="table table-striped table-bordered table-hover">
    <thead>
        <tr class="bg-info">
            <th>Id</th>
            <th>Bank Name</th>
            <th>Branch Name</th>
            <th>IFSC Code</th>
            <th>Account Number</th>
            <th>Update</th>
            <th>Delete</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($banks as $bank): ?>
        <tr>
            <td><?php echo e($bank->id); ?></td>
            <td><?php echo e($bank->bank_name); ?></td>
            <td><?php echo e($bank->branch_name); ?></td>
            <td><?php echo e($bank->ifsc_code); ?></td>
            <td><?php echo e($bank->account_no); ?></td>

            <?php if( $bank->user_id == $loggedInUser ): ?>
            <td><a href="<?php echo e(route('banks.edit',$bank->id)); ?>" class="btn btn-warning">Update</a></td>

            <td>
                <?php echo Form::open(['method' => 'DELETE', 'route'=>['banks.destroy', $bank->id]]); ?>

                <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                <?php echo Form::close(); ?>

            </td>
            <?php else: ?>
            <td>&nbsp;</td>

            <td>&nbsp;</td>
            <?php endif; ?>

        </tr>
        <?php endforeach; ?>

    </tbody>
</table>
<?php echo e($banks->appends(['sort' => 'updated_at'])->render()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>