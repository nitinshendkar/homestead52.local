<?php $__env->startSection('header'); ?>
    <h1><?php echo e($user->title); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <table class="table table-striped table-bordered table-hover">
        <tbody>
        <tr><td>First Name</td><td><?php echo e($user->title); ?></td> </tr>
        <tr><td>Last Name</td><td><?php echo e($user->author->name); ?></td> </tr>
        <tr><td>Home Address</td><td><?php echo e($user->description); ?></td> </tr>
        <tr><td>Office Address</td><td><?php echo e($user->description); ?></td> </tr>
        <tr><td>Phone</td><td><?php echo e($user->description); ?></td> </tr>
        <tr><td>Employee Id</td><td><?php echo e($user->description); ?></td> </tr>
        <tr><td>Date Of Birth</td><td><?php echo e($user->description); ?></td> </tr>
        <tr><td>Date Of Joining</td><td><?php echo e($user->description); ?></td> </tr>
        <tr><td>photo</td><td><?php echo e($user->description); ?></td> </tr>
        <tr><td>signature</td><td><?php echo e($user->description); ?></td> </tr>
        <tr><td>Email</td><td><?php echo e($user->description); ?></td> </tr>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>