<?php $__env->startSection('content'); ?>
    <h1>Author's Store</h1>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach($errors->all() as $error): ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <a href="<?php echo e(url('/authors/create')); ?>" class="btn btn-success">Create Author</a>
    <hr>
    <table class="table table-striped table-bordered table-hover">
        <thead>
        <tr class="bg-info">
            <th>Id</th>
            <th>Author Name</th>
            <th>update</th>
            <th>Delete</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach($authors as $author): ?>
            <tr>
                <td><?php echo e($author->id); ?></td>
                <td><?php echo e($author->name); ?></td>
                <td><a href="<?php echo e(route('authors.edit',$author->id)); ?>" class="btn btn-warning">Update</a></td>

                <td>
                    <?php echo Form::open(['method' => 'DELETE', 'route'=>['authors.destroy', $author->id]]); ?>

                    <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; ?>

        </tbody>
    </table>
    <?php echo e($authors->appends(['sort' => 'updated_at'])->render()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>