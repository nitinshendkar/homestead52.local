<?php $__env->startSection('header'); ?>
    <h1>Message Board</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<a href="<?php echo e(url('/messageboard/create')); ?>" class="btn btn-success">Create Message</a>
    <hr>
    
    <table class="table table-striped table-bordered table-hover">
        <thead>
        <tr class="bg-info">
            <th>Id</th>
            <th>From User</th>
            <th>To Role Type</th>
            <th>Message</th>
            
        </tr>
        </thead>
        <tbody>
        <?php foreach($messages as $message): ?>
            <tr>
                
                <td><?php echo e($message->id); ?></td>
                <td><?php echo e($message->name); ?></td>
                <td><?php echo e($message->role_name); ?></td>
                <td><?php echo e($message->mesaage); ?></td>
                
            </tr>
        <?php endforeach; ?>

        </tbody>

    </table>

   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>