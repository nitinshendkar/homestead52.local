<?php $__env->startSection('content'); ?>
    <h1>Create Proffessional Details</h1>
    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach($errors->all() as $error): ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php echo Form::open(['route' => 'proffessional.store', 'files' => true]); ?>

    <div class="form-group">
        <?php echo Form::label('Designation', 'Designation:'); ?>

        <?php echo Form::text('designation',null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('Organization', 'Organization:'); ?>

        <?php echo Form::text('organization',null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('Current Working', 'Current Working:'); ?>

        <?php echo Form::text('current_working',null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('Joining Date', 'Joining Date:'); ?>

        <?php echo Form::date('joining_date',null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('Reveliving Date', 'Reveliving Date:'); ?>

        <?php echo Form::date('reveliving_date',null,['class'=>'form-control']); ?>

    </div>
    
    <div class="form-group">
        <?php echo Form::submit('Save', ['class' => 'btn btn-primary form-control']); ?>

    </div>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>