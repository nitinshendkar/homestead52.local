<?php $__env->startSection('header'); ?>
    <h1>Users</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach($errors->all() as $error): ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php if(!empty(session('success'))): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>

    <?php endif; ?>

    <a href="<?php echo e(url('/users/create')); ?>" class="btn btn-success">Create User</a>
    <hr>
    <table class="table table-striped table-bordered table-hover">
        <thead>
        <tr class="bg-info">
            <th>Id</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>phone</th>
            <th>employee Id</th>
            <th>email</th>
            <th>update</th>
            <th>Delete</th>
            <th>Reset</th>
        </tr>
        </thead>
        <tbody>
         
        <?php foreach($users as $user): ?>
            <tr>
                
                <td><?php echo e($user->id); ?></td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->lastname); ?></td>
                <td><?php echo e($user->phone); ?></td>
                <td><?php echo e($user->emp_id); ?></td>
                <td><?php echo e($user->email); ?></td>
                
               <?php if( $user->id == $loggedInUser ): ?>
               <td><a href="<?php echo e(route('users.edit',$user->id)); ?>" class="btn btn-warning">Update</a></td>
 
                <td>
                    <?php echo Form::open(['method' => 'DELETE', 'route'=>['users.destroy', $user->id]]); ?>

                    <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                    <?php echo Form::close(); ?>

                </td>
                <?php else: ?>
                <td>&nbsp;</td>
 
                <td>&nbsp;</td>
               <?php endif; ?>
               <td>
                    <?php echo Form::open(['method' => 'POST', 'route'=>['users.reset', $user->id]]); ?>

                    <?php echo Form::submit('Reset', ['class' => 'btn btn-danger']); ?>

                    <?php echo Form::close(); ?>

                </td>
                
            </tr>
        <?php endforeach; ?>

        </tbody>

    </table>

    <?php echo e($users->appends(['sort' => 'updated_at'])->render()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>