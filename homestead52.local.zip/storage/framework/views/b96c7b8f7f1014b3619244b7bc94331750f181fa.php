<?php $__env->startSection('content'); ?>
    <h1>Update Book</h1>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach($errors->all() as $error): ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php echo Form::model($address,['method' => 'PATCH','route'=>['address.update',$address->id]]); ?>

    <div class="form-group">
        <?php echo Form::label('State', 'State:'); ?>

        <?php echo Form::select('state_id',$arrayReKeystates, $address->state_id,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('District', 'District:'); ?>

        <?php echo Form::select('district_id', $arrayReKeydistricts, $address->district_id,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('Taluka', 'Taluka:'); ?>

        <?php echo Form::select('taluka_id', $arrayReKeytalukas, $address->taluka_id,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('Address Type', 'Address Type:'); ?>

        <?php echo Form::select('address_type', ['P' => 'Permenant', 'T' => 'Temporary'], 'S',['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('Village Name', 'Village Name:'); ?>

        <?php echo Form::text('village',null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::submit('Update', ['class' => 'btn btn-primary']); ?>

    </div>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>