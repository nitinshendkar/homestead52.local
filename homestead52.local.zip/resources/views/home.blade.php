@extends('layout/base')

@section('content')
    <h1>Message Board</h1>
@stop